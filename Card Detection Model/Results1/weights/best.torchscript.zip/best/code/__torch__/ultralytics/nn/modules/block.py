class C2f(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_5.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_8.Conv
  m : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.ultralytics.nn.modules.block.C2f,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_203.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    _0 = getattr(m, "0")
    cv1 = self.cv1
    _1 = (cv1).forward(argument_1, argument_2, )
    _2 = torch.split_with_sizes(_1, [16, 16], 1)
    _3, input, = _2
    _4 = [_3, input, (_0).forward(argument_1, input, )]
    input0 = torch.cat(_4, 1)
    return (cv2).forward(argument_1, input0, )
class Bottleneck(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_11.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_14.Conv
  def forward(self: __torch__.ultralytics.nn.modules.block.Bottleneck,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_203.SiLU,
    input: Tensor) -> Tensor:
    cv2 = self.cv2
    cv1 = self.cv1
    _4 = (cv2).forward(argument_1, (cv1).forward(argument_1, input, ), )
    return torch.add(input, _4)
class SPPF(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_85.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_88.Conv
  m : __torch__.torch.nn.modules.pooling.MaxPool2d
  def forward(self: __torch__.ultralytics.nn.modules.block.SPPF,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_203.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    cv1 = self.cv1
    _5 = (cv1).forward(argument_1, argument_2, )
    _6 = (m).forward(_5, )
    _7 = (m).forward1(_6, )
    input = torch.cat([_5, _6, _7, (m).forward2(_7, )], 1)
    return (cv2).forward(argument_1, input, )
class DFL(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_208.Conv2d
  def forward(self: __torch__.ultralytics.nn.modules.block.DFL,
    x: Tensor) -> Tensor:
    conv = self.conv
    b = ops.prim.NumToTensor(torch.size(x, 0))
    _8 = int(b)
    _9 = int(b)
    a = ops.prim.NumToTensor(torch.size(x, 2))
    _10 = int(a)
    _11 = torch.transpose(torch.view(x, [_9, 4, 16, int(a)]), 2, 1)
    input = torch.softmax(_11, 1)
    distance = torch.view((conv).forward(input, ), [_8, 4, _10])
    return distance
